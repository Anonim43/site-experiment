PredictorsAnalyzer is a Ruby script that collects, for each merge scenario, metrics about the factors concerning to modularity, size, and timing of contributions.

To run this script, you need to follow the instructions: 

*******Install all dependencies
1) To install the bundler to manage all dependencies, open a terminal window and run this command: gem install bundler
2) To install all dependencies specified on the Gemfile: bundle install  

*******Configure properties file

3) Inform the directory where the input data (resulting from the Mining step) will be placed and the directory where the results will be saved.

For example:
pathInput=</input/>
pathOutput=</output/>

***********Configure projectsList file
4) The projectsList  file contains all projects used to compose the study sample. So, each line of this file should specify a project repository used and should be set as follows:
For instance, for a project  repository located in https://github.com/user1/projectAB, the corresponding line should be set as "user1/projectAB". That is, 
 - The owner of the project, in this example, user1, and 
 - The name of the project, projectAB
 - Each project name needs to start and finish with ".
 
***** Run this script
5) Run the MainAnalysisProjects.rb file by using the command line: ruby MainAnalysisProjects.rb